<?php

namespace App\Http\Controllers;
use App\Models\Customer;
use App\Models\Mobile;

use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function add_customer(){

        
        $phone = Mobile::find(9)->customer;
        dd($phone);

       

    }

    
}
